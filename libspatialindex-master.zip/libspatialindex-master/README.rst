.. image:: https://dev.azure.com/hobuinc/libspatialindex/_apis/build/status/libspatialindex.libspatialindex?branchName=master

*****************************************************************************
 libspatialindex
*****************************************************************************


:Author: Marios Hadjieleftheriou
:Contact: mhadji@gmail.com
:Revision: 1.9.1
:Date: 10/19/2019

See http://libspatialindex.org for full documentation.
