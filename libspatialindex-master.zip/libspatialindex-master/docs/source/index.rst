*****************************************************************************
 libspatialindex
*****************************************************************************

.. toctree::
   :maxdepth: 1

   install
   Github <https://github.com/libspatialindex/libspatialindex>
   community
   overview
   Class Documentation <http://libspatialindex.org/doxygen/>



.. include:: introduction.rst
.. include:: ../../COPYING
.. include:: download.rst


