echo "Running unit tests..."
./test
result=$?
echo "Unit tests completed : $result"
exit $result
